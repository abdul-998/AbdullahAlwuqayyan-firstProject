//
//  MapViewController.swift
//  OnTheMap
//
//  Created by abdul on 07/10/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import UIKit
import MapKit
import SafariServices

class MapViewController: UIViewController {
    
    
    @IBOutlet weak var mapView: MKMapView!
    
    
    private var Pointannotations = [MKPointAnnotation]()
    
    var usersDArray = ModelDataArray.shared.usersDataArray
    
    override func viewWillAppear(_ animated: Bool) {
        
        super.viewWillAppear(animated)
        getAllUsersData()
    }
    
    
    func getAllUsersData(){
        
        self.usersDArray.removeAll()
        
        Pointannotations.removeAll()
        
        let allAnno = self.mapView.annotations
        
        self.mapView.removeAnnotations(allAnno)
        
        ActivityIndicator.startActivityIndicator(view: self.view)
        
        OTMParseClient.sharedInstance().getAllDataFormUsers { (success, usersData, errorString) in
            
            if success {
                
                self.usersDArray = usersData as! [Results]
                
                self.organizingUsersData(userDataArray: self.usersDArray as! [Results])
                
                self.stopActivityIdecator()
            }else {
                
                self.stopActivityIdecator()
                Alert.showBasicAlert(on: self, with: errorString!)
            }
        }
        
    }
    
    
    
    func stopActivityIdecator(){
        
        DispatchQueue.main.async {
            ActivityIndicator.stopActivityIndicator()
        }
    }
    
    func organizingUsersData(userDataArray:[Results]){
        
        
        for i in userDataArray {
            
            
            if let latitude = i.latitude , let longitude = i.longitude , let first = i.firstName ,let last = i.lastName , let mediaURL = i.mediaURL {
                
                let latit = CLLocationDegrees(latitude)
                let longit = CLLocationDegrees(longitude)
                
                let coord = CLLocationCoordinate2D(latitude: latit, longitude: longit)
                
                let Panno = MKPointAnnotation()
                
                Panno.coordinate = coord
                
                Panno.title = "\(first) \(last)"
                Panno.subtitle = mediaURL
                
                self.Pointannotations.append(Panno)
                
                
                
            }
            DispatchQueue.main.async {
                self.mapView.addAnnotations(self.Pointannotations)
                ActivityIndicator.stopActivityIndicator()
                
                
            }
            
            
        }
        
    }
    
    
    
    @IBAction func refreshNewData(_ sender: Any) {
        
        getAllUsersData()
    }
    
    @IBAction func logoutTapped(_ sender: Any) {
        
        OTMUdacityClient.sharedInstance().deleteSession { (success, sessionID, errorString) in
            
            DispatchQueue.main.async {
                if success {
                    self.dismiss(animated: true, completion: nil)
                    
                }else {
                    Alert.showBasicAlert(on: self, with: errorString!)
                }
            }
            
        }
        
    }
    
    
    @IBAction func AddUserLocationTapped(_ sender: Any) {
        
        OTMParseClient.sharedInstance().getuserDataByUniqueKey { (success, objectID, errorString) in
            
            if success {
                
                // if the usersData is not equal nil : that mean the user did already post Location to parse ( get objectId and Ask if he want to update !)
                // but if the usersData is equal nil : that mean the user never post his Location ! (let him post !)
                if objectID == nil {
                    DispatchQueue.main.async {
                        self.performSegue(withIdentifier: "toAddLocation", sender: nil)
                        
                    }
                }else {
                    //ask user if his want to overwriting!
                    //                    Alert.showAlertWithTwoButtons(on: self, with: "User \(OTMParseClient.sharedInstance().userFullName!) Has Already Posted a Stdent Location. Whould you Like to Overwrite Thier Location?")
                    
                    Alert.showAlertWithTwoButtons(on: self, with: "User \(OTMUdacityClient.sharedInstance().nickname!) Has Already Posted a Stdent Location. Whould you Like to Overwrite Thier Location?", completionHandlerForAlert: { (action) in
                        
                        self.performSegue(withIdentifier: "toAddLocation", sender: nil)
                        
                    })
                    
                }
                
                
            }else {
                Alert.showBasicAlert(on: self, with: errorString!)
            }
        }
        
    }
    
    
}



extension MapViewController : MKMapViewDelegate{
    
    // MARK: - MKMapViewDelegate
    
    // Here we create a view with a "right callout accessory view". You might choose to look into other
    // decoration alternatives. Notice the similarity between this method and the cellForRowAtIndexPath
    // method in TableViewDataSource.
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        
        let Id = "pin"
        
        var pView = mapView.dequeueReusableAnnotationView(withIdentifier: Id) as? MKPinAnnotationView
        
        if pView == nil {
            pView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: Id)
            pView!.canShowCallout = true
            pView!.pinTintColor = .red
            pView!.rightCalloutAccessoryView = UIButton(type: .infoDark)
        }
        else {
            pView!.annotation = annotation
        }
        
        
        return pView
    }
    
    
    
    func openUrlInSafari(url:URL){
        
        if url.absoluteString.contains("http://"){
            let svc = SFSafariViewController(url: url)
            present(svc, animated: true, completion: nil)
        }else {
            DispatchQueue.main.async {
                Alert.showBasicAlert(on: self, with: "Cannot Open , Because it's Not Vailed Website !!")
            }
        }
        
    }
    
    // This delegate method is implemented to respond to taps. It opens the system browser
    // to the URL specified in the annotationViews subtitle property.
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
        if control == view.rightCalloutAccessoryView {
            
            if let Open = view.annotation?.subtitle! {
                guard let url = URL(string: Open) else {return}
                openUrlInSafari(url:url)
                
            }
        }
    }
    
    func mapView(mapView: MKMapView, annotationView: MKAnnotationView, calloutAccessoryControlTapped cont: UIControl) {
        
        if cont == annotationView.rightCalloutAccessoryView {
            guard let Url = annotationView.annotation?.subtitle else {
                return
                
            }
            guard let sUrl = Url else {
                return
                
            }
            guard let url = URL(string: sUrl) else {
                return
                
            }
            openUrlInSafari(url:url)
            
        }
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
