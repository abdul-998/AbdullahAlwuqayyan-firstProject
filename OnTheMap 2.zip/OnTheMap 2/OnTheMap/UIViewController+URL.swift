//
//  UIViewController+URL.swift
//  OnTheMap
//
//  Created by abdul on 12/10/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import UIKit


extension UIViewController{
    
    
    func openUrlInSafari(url:URL){
        
        if url.absoluteString.contains("http://"){
            let svc = SFSafariViewController(url: url)
            present(svc, animated: true, completion: nil)
        }else {
            DispatchQueue.main.async {
                Alert.showBasicAlert(on: self, with: "Cannot Open , Because it's Not Vailed Website !!")
            }
        }
        
    }
    
    
    
}




