import Foundation
// Udacity from JSON

struct UdacitySessionBody : Codable {
    
    let udacity : Udacity
}

struct Udacity : Codable {
    
    let username:String
    let password:String
}
//post-session

struct UdacitySessionResponse : Codable {
    let account : Account
    let session : Session
    
}


struct Account : Codable {
    let registered : Bool?
    let key : String?
}

struct SessionDelete : Codable {
    let session : Session
}

struct Session : Codable {
    let id : String?
    let expiration : String?
}

//Mark: User Data (Frist and Last Name)

struct UdacityUserData : Codable {
    let nickname : String?
    
}

struct StudentLocations : Codable {
    let results : [Results]?
}

struct Results : Codable {
    let createdAt:String?
    let firstName:String?
    let lastName:String?
    let latitude:Double?
    let longitude:Double?
    let mapString:String?
    let mediaURL:String?
    let uniqueKey:String?
    let updatedAt:String?
    let objectId:String?
    
}



struct StudentLocationsBody : Codable {
    let uniqueKey:String?
    let firstName:String?
    let lastName:String?
    let mapString:String?
    let mediaURL:String?
    let latitude:Double?
    let longitude:Double?
}

//post-student-location
struct StudentLocationsResponse : Codable {
    let createdAt : String?
    let objectId : String?
    
}

struct StudentLocationsUpdateResponse : Codable {
    let createdAt : String?
}
