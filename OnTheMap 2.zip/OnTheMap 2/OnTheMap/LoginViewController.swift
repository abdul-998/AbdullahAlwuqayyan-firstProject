
import UIKit
import SafariServices

class LoginViewController: UIViewController {
    
    @IBOutlet weak var emailText: UITextField!
    
    @IBOutlet weak var passwordText: UITextField!
    
    @IBOutlet weak var loginButton: UIButton!
    
    
    override func viewWillDisappear(_ animated: Bool) {
        
        emailText.text = ""
        
        passwordText.text = ""
        
    }
    
    
    @IBAction func loginTapped(_ sender: Any) {
        
        if emailText.text == "" || passwordText.text == ""{
            Alert.showBasicAlert(on: self, with: "Username and Password cannot be empty !")
            
        }else {
            
            ActivityIndicator.startActivityIndicator(view: self.loginButton)
            
            guard let username = emailText.text else {
                return
                
            }
            guard let password = passwordText.text else {
                return
                
            }
            
            let jsonB = UdacitySessionBody(udacity: Udacity(username: username, password: password))
            
            loginButton.isEnabled = false
            
            OTMUdacityClient.sharedInstance().authenticateWithViewController(self, jsonBody: jsonB) { (success,errorString) in
                
                DispatchQueue.main.async {
                    
                    if success {
                        self.loginButton.isEnabled = true
                        
                        ActivityIndicator.stopActivityIndicator()
                        
                        self.completeLogin()
                    }else {
                        
                        self.loginButton.isEnabled = true
                        
                        ActivityIndicator.stopActivityIndicator()
                        Alert.showBasicAlert(on: self, with: errorString!)
                    }
                }
                
            }
        }
        
    }
    
    private func completeLogin() {
        
        let controller = storyboard!.instantiateViewController(withIdentifier: "ManagerTabBarController") as! UITabBarController
        present(controller, animated: true, completion: nil)
    }
    
    
    
    @IBAction func signupTapped(_ sender: Any) {
        
        let url = URL(string: "https://www.udacity.com/account/auth#!/signup")
        
        guard let newUrl = url else {
            return
            
        }
        let s = SFSafariViewController(url: newUrl)
        
        present(s, animated: true, completion: nil)
    }
    
    
}

extension LoginViewController: UITextFieldDelegate{
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        textField.resignFirstResponder()
        
        return true
    }
}
