
extension OTMParseClient {
    
    
    
    struct Constants {
        
        
        static let ApiKey = "QuWThTdiRmTux3YaDseUSEpUKo7aBYM737yKd4gY"
        static let ApplicationID = "QrX47CA9cyuGewLdsL7o5Eb8iug6Em8ye0dnAbIr"
        
        static let ApiScheme = "https"
        static let ApiHost = "onthemap-api.udacity.com"
        static let ApiPath = "/parse/classes"
        
    }
    
    struct URLKeys {
        static let UserID = "id"
        static let ObjectId = "id"
        
    }
    
    
    struct Methods {
        
        static let StudentLocation = "/StudentLocation"
        static let StudentLocationUpdate = "/StudentLocation/{id}"
    }
    
    struct ParameterKeys {
        static let Order = "order"
        static let Limit = "limit"
        static let Where = "where"
        
    }
    
    struct ParameterValues {
        static let Order = "-updatedAt"
        static let Limit = "100"
        static let Where = "{\"uniqueKey\":\"{id}\"}"
        
        
    }
    
    
}
