//
//  PhotoCollectionViewCell.swift
//  VTAbdul
//
//  Created by abdul on 6/25/19.
//  Copyright © 2019 Udacity. All rights reserved.
//

import UIKit

class PhotoCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var imageFlikr: UIImageView!
    
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    @IBOutlet weak var selectedView: UIView!
    
    
    
}
