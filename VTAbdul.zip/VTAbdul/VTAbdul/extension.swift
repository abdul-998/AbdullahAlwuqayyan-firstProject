//
//  extension.swift
//  VTAbdul
//
//  Created by abdul on 6/25/19.
//  Copyright © 2019 Udacity. All rights reserved.
//


import Foundation
import CoreData

extension Pin {
    public override func awakeFromInsert() {
        super.awakeFromInsert()
        creationDate = Date()
    }
}

extension Photo {
    public override func awakeFromInsert() {
        super.awakeFromInsert()
        creationDate = Date()
    }
}

